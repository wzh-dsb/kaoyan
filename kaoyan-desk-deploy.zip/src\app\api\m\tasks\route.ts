import { prisma } from '@/lib/prisma'
import { apiUser } from '@/lib/api-user'
import { todayStr } from '@/lib/date'

/** GET /api/m/tasks?date=YYYY-MM-DD —— 指定日期(默认今天)的任务列表 */
export async function GET(req: Request) {
  const user = await apiUser()
  if (!user) return Response.json({ error: '未登录' }, { status: 401 })

  const date = new URL(req.url).searchParams.get('date') ?? todayStr()
  if (!/^\d{4}-\d{2}-\d{2}$/.test(date)) {
    return Response.json({ error: '日期格式不正确' }, { status: 400 })
  }

  const tasks = await prisma.task.findMany({
    where: { userId: user.id, planDate: date },
    orderBy: [{ done: 'asc' }, { sortOrder: 'desc' }],
  })
  return Response.json({ tasks })
}

/** POST /api/m/tasks —— 新建任务 {title, subject?, planDate?, pomodoros?} */
export async function POST(req: Request) {
  const user = await apiUser()
  if (!user) return Response.json({ error: '未登录' }, { status: 401 })

  const body = await req.json().catch(() => null)
  const title = String(body?.title ?? '').trim()
  if (!title) return Response.json({ error: '任务内容不能为空' }, { status: 400 })

  const planDate = String(body?.planDate ?? '') || todayStr()
  if (!/^\d{4}-\d{2}-\d{2}$/.test(planDate)) {
    return Response.json({ error: '日期格式不正确' }, { status: 400 })
  }
  const subject = String(body?.subject ?? '').trim() || null
  const pomodoros = Math.max(1, Number(body?.pomodoros) || 1)

  const task = await prisma.task.create({
    data: { userId: user.id, title, subject, planDate, pomodoros, sortOrder: Date.now() },
  })
  return Response.json({ task }, { status: 201 })
}
