import { prisma } from '@/lib/prisma'
import { apiUser } from '@/lib/api-user'

const SUBJECTS = ['政治', '英语', '数学', '专业课']

/** GET /api/m/mock-exams —— 模考成绩列表 */
export async function GET() {
  const user = await apiUser()
  if (!user) return Response.json({ error: '未登录' }, { status: 401 })

  const exams = await prisma.mockExam.findMany({
    where: { userId: user.id },
    orderBy: { examDate: 'desc' },
    take: 100,
  })
  return Response.json({ exams })
}

/** POST /api/m/mock-exams —— 新增模考 {examDate, name, subject, score, total?, note?} */
export async function POST(req: Request) {
  const user = await apiUser()
  if (!user) return Response.json({ error: '未登录' }, { status: 401 })

  const body = await req.json().catch(() => null)
  const examDate = String(body?.examDate ?? '')
  const name = String(body?.name ?? '').trim()
  const subject = String(body?.subject ?? '')
  const score = Number(body?.score)
  const total = Number(body?.total) || 100
  const note = String(body?.note ?? '').trim() || null

  if (!/^\d{4}-\d{2}-\d{2}$/.test(examDate)) {
    return Response.json({ error: '日期格式不正确' }, { status: 400 })
  }
  if (!name || !SUBJECTS.includes(subject)) {
    return Response.json({ error: '请填写名称和科目' }, { status: 400 })
  }
  if (!Number.isFinite(score) || score < 0) {
    return Response.json({ error: '分数不合法' }, { status: 400 })
  }

  const exam = await prisma.mockExam.create({
    data: { userId: user.id, examDate, name, subject, score, total, note },
  })
  return Response.json({ exam }, { status: 201 })
}
