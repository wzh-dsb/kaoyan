import { prisma } from '@/lib/prisma'
import { apiUser } from '@/lib/api-user'

/** GET /api/m/habits —— 习惯列表(含今日打卡状态) */
export async function GET() {
  const user = await apiUser()
  if (!user) return Response.json({ error: '未登录' }, { status: 401 })

  const [habits, logs] = await Promise.all([
    prisma.habit.findMany({ where: { userId: user.id }, orderBy: { createdAt: 'asc' } }),
    prisma.habitLog.findMany({
      where: { userId: user.id },
      orderBy: { date: 'desc' },
      take: 200, // 最近打卡记录,用于连续天数统计
    }),
  ])

  const byHabit = new Map<string, string[]>()
  logs.forEach((l) => {
    const arr = byHabit.get(l.habitId) ?? []
    if (!arr.includes(l.date)) arr.push(l.date)
    byHabit.set(l.habitId, arr)
  })

  return Response.json({
    habits: habits.map((h) => ({
      id: h.id,
      name: h.name,
      dates: byHabit.get(h.id) ?? [],
    })),
  })
}

/** POST /api/m/habits —— 新建习惯 {name} */
export async function POST(req: Request) {
  const user = await apiUser()
  if (!user) return Response.json({ error: '未登录' }, { status: 401 })

  const body = await req.json().catch(() => null)
  const name = String(body?.name ?? '').trim()
  if (!name) return Response.json({ error: '习惯名称不能为空' }, { status: 400 })

  const habit = await prisma.habit.create({ data: { userId: user.id, name } })
  return Response.json({ habit: { id: habit.id, name: habit.name, dates: [] } }, { status: 201 })
}
