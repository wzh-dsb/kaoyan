import { prisma } from '@/lib/prisma'
import { apiUser } from '@/lib/api-user'

/** DELETE /api/m/habits/:id —— 删除习惯(含打卡记录) */
export async function DELETE(_req: Request, { params }: { params: Promise<{ id: string }> }) {
  const user = await apiUser()
  if (!user) return Response.json({ error: '未登录' }, { status: 401 })

  const { id } = await params
  const habit = await prisma.habit.findUnique({ where: { id } })
  if (!habit || habit.userId !== user.id) return Response.json({ error: '习惯不存在' }, { status: 404 })

  await prisma.habit.delete({ where: { id } })
  return Response.json({ ok: true })
}
