import { prisma } from '@/lib/prisma'
import { verifyPassword, SESSION_DAYS } from '@/lib/auth'

const EMAIL_RE = /^[^\s@]+@[^\s@]+\.[^\s@]+$/

/** 小程序/第三方客户端登录:POST {email, password} → {token, user} */
export async function POST(req: Request) {
  const body = await req.json().catch(() => null)
  const email = String(body?.email ?? '').trim().toLowerCase()
  const password = String(body?.password ?? '')

  if (!EMAIL_RE.test(email) || !password) {
    return Response.json({ error: '请输入邮箱和密码' }, { status: 400 })
  }

  const user = await prisma.user.findUnique({ where: { email } })
  if (!user) return Response.json({ error: '邮箱或密码错误' }, { status: 401 })

  const ok = await verifyPassword(password, user.passwordHash)
  if (!ok) return Response.json({ error: '邮箱或密码错误' }, { status: 401 })

  const token = crypto.randomUUID()
  await prisma.session.create({
    data: {
      token,
      userId: user.id,
      expiresAt: new Date(Date.now() + SESSION_DAYS * 86_400_000),
    },
  })

  return Response.json({ token, user: publicUser(user) })
}

function publicUser(u: {
  id: string
  email: string
  nickname: string | null
  targetSchool: string | null
  targetMajor: string | null
  examDate: Date | null
}) {
  return {
    id: u.id,
    email: u.email,
    nickname: u.nickname,
    targetSchool: u.targetSchool,
    targetMajor: u.targetMajor,
    examDate: u.examDate,
  }
}
