import { prisma } from '@/lib/prisma'
import { apiUser } from '@/lib/api-user'

/** GET /api/m/profile —— 资料(与 /api/me 等价,顺手提供) */
export async function GET() {
  const user = await apiUser()
  if (!user) return Response.json({ error: '未登录' }, { status: 401 })
  return Response.json({ user })
}

/** PUT /api/m/profile —— 更新资料 {nickname?, targetSchool?, targetMajor?, examDate?} */
export async function PUT(req: Request) {
  const user = await apiUser()
  if (!user) return Response.json({ error: '未登录' }, { status: 401 })

  const body = await req.json().catch(() => null)
  const nickname = String(body?.nickname ?? '').trim() || null
  const targetSchool = String(body?.targetSchool ?? '').trim() || null
  const targetMajor = String(body?.targetMajor ?? '').trim() || null
  const examDateRaw = String(body?.examDate ?? '')
  const examDate = examDateRaw ? new Date(examDateRaw + 'T00:00:00+08:00') : null

  const updated = await prisma.user.update({
    where: { id: user.id },
    data: { nickname, targetSchool, targetMajor, examDate },
  })
  return Response.json({ user: updated })
}
