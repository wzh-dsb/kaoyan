import { getSession } from '@/lib/auth'
import { prisma } from '@/lib/prisma'
import { thisWeekStart } from '@/lib/date'
import { consumeAiQuota, getAiRemaining } from '@/lib/ai-usage'
import { generateReportText } from '@/lib/weekly-report'

// 认领阈值:记录 pending 超过该时长(秒)后,任何查询请求可接手执行生成
const CLAIM_SECONDS = 5

type ReportRecord = {
  id: string
  weekStart: string
  status: string
  report: string | null
  error: string | null
}

function toClient(r: {
  id: string
  weekStart: string
  status: string
  report: string | null
  error: string | null
}): ReportRecord {
  return { id: r.id, weekStart: r.weekStart, status: r.status, report: r.report, error: r.error }
}

/**
 * POST /api/report —— 生成(或重新生成)本周周报
 * 点击即重新生成:扣配额后重置为 pending 并调用 AI。
 * 生成结果先落库再返回;若客户端中途断开,记录保持 pending,
 * 下次任何 GET 查询会认领并完成生成,数据不会丢。
 */
export async function POST() {
  const session = await getSession()
  if (!session) return Response.json({ error: '未登录' }, { status: 401 })

  const userId = session.user.id
  const weekStart = thisWeekStart()

  const existing = await prisma.aiReport.findUnique({
    where: { userId_weekStart: { userId, weekStart } },
  })

  // 正在生成中:直接返回当前状态,不重复消耗配额
  if (existing?.status === 'pending') {
    return Response.json({ record: toClient(existing) })
  }

  // 配额检查(消耗一次)
  const quota = await consumeAiQuota(userId, 'report')
  if (!quota.ok) {
    return Response.json(
      { error: '今日 AI 周报次数已用完,明天再来吧 ✋', remaining: 0 },
      { status: 429 },
    )
  }

  // 已有记录(done/error)或新周 → 重置为 pending 重新生成。
  // 重新生成(此前 done)时保留旧内容,生成失败还能回退,不白丢
  const wasDone = existing?.status === 'done'
  const record = await prisma.aiReport.upsert({
    where: { userId_weekStart: { userId, weekStart } },
    update: {
      status: 'pending',
      error: null,
      ...(wasDone ? {} : { report: null }),
    },
    create: { userId, weekStart, status: 'pending' },
  })

  const result = await generateReportText(userId)
  const updated = await prisma.aiReport.update({
    where: { id: record.id },
    data: result.ok
      ? { status: 'done', report: result.report }
      : { status: 'error', error: result.error },
  })

  return Response.json({ record: toClient(updated), remaining: quota.remaining })
}

/**
 * GET /api/report?scope=week|history
 * scope=week:返回本周记录状态;若为 pending 且超时未完成,则由本次请求认领执行
 * scope=history:返回历史周报列表(不含本周)
 */
export async function GET(req: Request) {
  const session = await getSession()
  if (!session) return Response.json({ error: '未登录' }, { status: 401 })

  const userId = session.user.id
  const url = new URL(req.url)
  const scope = url.searchParams.get('scope') ?? 'week'

  if (scope === 'history') {
    const records = await prisma.aiReport.findMany({
      where: { userId, weekStart: { lt: thisWeekStart() }, status: 'done' },
      orderBy: { weekStart: 'desc' },
      take: 12,
    })
    return Response.json({
      records: records.map((r) => ({ weekStart: r.weekStart, report: r.report })),
    })
  }

  // —— 本周 ——
  const weekStart = thisWeekStart()
  const record = await prisma.aiReport.findUnique({
    where: { userId_weekStart: { userId, weekStart } },
  })

  const remaining = await getAiRemaining(userId, 'report')

  if (!record || record.status !== 'pending') {
    return Response.json({ record: record ? toClient(record) : null, remaining })
  }

  // pending:尝试认领(乐观锁,5 秒内由原请求处理,避免重复生成)
  const locked = await prisma.aiReport.updateMany({
    where: {
      id: record.id,
      status: 'pending',
      updatedAt: { lt: new Date(Date.now() - CLAIM_SECONDS * 1000) },
    },
    data: { updatedAt: new Date() },
  })
  if (locked.count === 1) {
    // 认领成功:执行生成(即使用户已切页,下次进来也会完成)
    const result = await generateReportText(userId)
    const updated = await prisma.aiReport.update({
      where: { id: record.id },
      data: result.ok
        ? { status: 'done', report: result.report }
        : { status: 'error', error: result.error },
    })
    return Response.json({ record: toClient(updated) })
  }

  // 未认领(原请求正在生成中),返回当前状态,前端继续轮询
  return Response.json({ record: toClient(record) })
}
