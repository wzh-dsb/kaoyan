import { prisma } from '@/lib/prisma'
import { apiUser } from '@/lib/api-user'
import { MISTAKE_REASONS, MISTAKE_SUBJECTS } from '@/lib/constants'

/** GET /api/m/mistakes?subject=&reason= —— 错题列表(可按科目/错因筛选) */
export async function GET(req: Request) {
  const user = await apiUser()
  if (!user) return Response.json({ error: '未登录' }, { status: 401 })

  const { searchParams } = new URL(req.url)
  const subject = searchParams.get('subject')
  const reason = searchParams.get('reason')

  const mistakes = await prisma.mistake.findMany({
    where: {
      userId: user.id,
      ...(subject && subject !== '全部' ? { subject } : {}),
      ...(reason && reason !== '全部' ? { reason } : {}),
    },
    orderBy: { createdAt: 'desc' },
    take: 200,
  })
  return Response.json({ mistakes })
}

/** POST /api/m/mistakes —— 新增错题 {subject, reason, question, chapter?, solution?} */
export async function POST(req: Request) {
  const user = await apiUser()
  if (!user) return Response.json({ error: '未登录' }, { status: 401 })

  const body = await req.json().catch(() => null)
  const subject = String(body?.subject ?? '')
  const reason = String(body?.reason ?? '')
  const question = String(body?.question ?? '').trim()
  const chapter = String(body?.chapter ?? '').trim() || null
  const solution = String(body?.solution ?? '').trim() || null

  if (!MISTAKE_SUBJECTS.includes(subject) || !MISTAKE_REASONS.includes(reason as never)) {
    return Response.json({ error: '科目或错因不合法' }, { status: 400 })
  }
  if (!question) return Response.json({ error: '题目内容不能为空' }, { status: 400 })

  const mistake = await prisma.mistake.create({
    data: { userId: user.id, subject, reason, question, chapter, solution },
  })
  return Response.json({ mistake }, { status: 201 })
}
