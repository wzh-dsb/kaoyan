import { prisma } from '@/lib/prisma'
import { apiUser } from '@/lib/api-user'
import { grantAiQuota, getAiRemaining, type AiFeature } from '@/lib/ai-usage'
import { todayStr } from '@/lib/date'

// 每日通过广告解锁的上限(防接口滥用;真机广告播放本身有微信侧频率限制)
const MAX_UNLOCKS_PER_DAY = 5

const FEATURES: AiFeature[] = ['report', 'ocr']

/**
 * POST /api/m/ai-unlock —— 看激励视频广告后解锁一次 AI 次数 {feature}
 * 说明:广告播放结果来自微信侧(流量主收入与解锁解耦),
 * 此处信任前端"播放完成"回调,但做每日次数上限兜底。
 */
export async function POST(req: Request) {
  const user = await apiUser()
  if (!user) return Response.json({ error: '未登录' }, { status: 401 })

  const body = await req.json().catch(() => null)
  const feature = String(body?.feature ?? '') as AiFeature
  if (!FEATURES.includes(feature)) {
    return Response.json({ error: '功能不正确' }, { status: 400 })
  }

  const today = todayStr()
  const usage = await prisma.aiUsage.findUnique({
    where: { userId_feature_date: { userId: user.id, feature, date: today } },
  })
  if ((usage?.extra ?? 0) >= MAX_UNLOCKS_PER_DAY) {
    return Response.json(
      { error: '今日解锁次数已达上限,明天再来吧 ✋', remaining: await getAiRemaining(user.id, feature) },
      { status: 429 },
    )
  }

  const remaining = await grantAiQuota(user.id, feature, 1)
  return Response.json({ remaining, extra: (usage?.extra ?? 0) + 1 })
}
