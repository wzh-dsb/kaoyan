import { prisma } from '@/lib/prisma'
import { apiUser } from '@/lib/api-user'

/** POST /api/m/habits/log —— 切换某日打卡 {habitId, date?} 未传日期默认今天 */
export async function POST(req: Request) {
  const user = await apiUser()
  if (!user) return Response.json({ error: '未登录' }, { status: 401 })

  const body = await req.json().catch(() => null)
  const habitId = String(body?.habitId ?? '')
  const date = String(body?.date ?? '')
  if (!habitId || !/^\d{4}-\d{2}-\d{2}$/.test(date)) {
    return Response.json({ error: '参数不正确' }, { status: 400 })
  }

  const habit = await prisma.habit.findUnique({ where: { id: habitId } })
  if (!habit || habit.userId !== user.id) return Response.json({ error: '习惯不存在' }, { status: 404 })

  const existing = await prisma.habitLog.findUnique({
    where: { habitId_date: { habitId, date } },
  })
  if (existing) {
    await prisma.habitLog.delete({ where: { id: existing.id } })
    return Response.json({ checked: false })
  }
  await prisma.habitLog.create({ data: { habitId, userId: user.id, date } })
  return Response.json({ checked: true })
}
