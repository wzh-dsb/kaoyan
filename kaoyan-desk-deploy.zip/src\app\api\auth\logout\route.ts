import { prisma } from '@/lib/prisma'

/** 小程序登出:POST + Authorization: Bearer <token>,删除服务端会话 */
export async function POST(req: Request) {
  const authHeader = req.headers.get('authorization')
  const token = authHeader?.startsWith('Bearer ') ? authHeader.slice(7) : null
  if (token) {
    await prisma.session.deleteMany({ where: { token } })
  }
  return Response.json({ ok: true })
}
