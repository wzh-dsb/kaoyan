import { getSession } from '@/lib/auth'
import { aiVisionConfigured, chatVision } from '@/lib/ai'
import { consumeAiQuota } from '@/lib/ai-usage'

const MAX_SIZE = 5 * 1024 * 1024 // 5MB

// 错题图片识别:上传图片 → 视觉模型 → 返回结构化错题信息
export async function POST(req: Request) {
  const session = await getSession()
  if (!session) return Response.json({ error: '未登录' }, { status: 401 })
  if (!aiVisionConfigured) {
    return Response.json(
      { error: 'AI 视觉未配置:请在 .env 中设置 AI_VISION_API_KEY 后重启服务' },
      { status: 503 },
    )
  }

  const formData = await req.formData().catch(() => null)
  const file = formData?.get('image')
  if (!(file instanceof File)) {
    return Response.json({ error: '缺少图片' }, { status: 400 })
  }
  if (file.size > MAX_SIZE) {
    return Response.json({ error: '图片不能超过 5MB' }, { status: 413 })
  }

  // 每日配额:参数校验通过后再消耗,防止空请求浪费配额
  const quota = await consumeAiQuota(session.user.id, 'ocr')
  if (!quota.ok) {
    return Response.json(
      { error: '今日错题识别次数已用完,明天再来吧 ✋', remaining: 0 },
      { status: 429 },
    )
  }

  const buf = Buffer.from(await file.arrayBuffer())
  const base64 = buf.toString('base64')

  const prompt = `这是一道考研复习错题的图片。识别图片内容并只输出一个 JSON 对象(不要输出 JSON 以外的任何文字):
{"subject":"科目(只能是 政治/英语/数学/专业课 之一,无法判断就填空字符串)","chapter":"章节或知识点,如'高数-极限'","question":"题目内容(尽量完整)","solution":"简要解题思路与正确答案"}
如果图片内容不是题目,输出 {"subject":"","chapter":"","question":"","solution":"图片不是题目"}`

  try {
    const text = await chatVision(base64, prompt)
    const jsonStr = text.match(/\{[\s\S]*\}/)?.[0]
    if (!jsonStr) {
      return Response.json({ error: '识别结果异常,请重试' }, { status: 422 })
    }
    const parsed = JSON.parse(jsonStr) as {
      subject?: string
      chapter?: string
      question?: string
      solution?: string
    }
    return Response.json({
      subject: parsed.subject ?? '',
      chapter: parsed.chapter ?? '',
      question: parsed.question ?? '',
      solution: parsed.solution ?? '',
      remaining: quota.remaining,
    })
  } catch (e) {
    return Response.json(
      { error: e instanceof Error ? e.message : '识别失败,请重试' },
      { status: 500 },
    )
  }
}
