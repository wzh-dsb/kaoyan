import { prisma } from '@/lib/prisma'
import { apiUser } from '@/lib/api-user'

/** PATCH /api/m/tasks/:id —— 切换完成状态 {done?} */
export async function PATCH(req: Request, { params }: { params: Promise<{ id: string }> }) {
  const user = await apiUser()
  if (!user) return Response.json({ error: '未登录' }, { status: 401 })

  const { id } = await params
  const task = await prisma.task.findUnique({ where: { id } })
  if (!task || task.userId !== user.id) return Response.json({ error: '任务不存在' }, { status: 404 })

  const body = await req.json().catch(() => null)
  const done = typeof body?.done === 'boolean' ? body.done : !task.done
  const updated = await prisma.task.update({ where: { id }, data: { done } })
  return Response.json({ task: updated })
}

/** DELETE /api/m/tasks/:id —— 删除任务 */
export async function DELETE(_req: Request, { params }: { params: Promise<{ id: string }> }) {
  const user = await apiUser()
  if (!user) return Response.json({ error: '未登录' }, { status: 401 })

  const { id } = await params
  const task = await prisma.task.findUnique({ where: { id } })
  if (!task || task.userId !== user.id) return Response.json({ error: '任务不存在' }, { status: 404 })

  await prisma.task.delete({ where: { id } })
  return Response.json({ ok: true })
}
