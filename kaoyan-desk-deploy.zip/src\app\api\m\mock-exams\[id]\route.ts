import { prisma } from '@/lib/prisma'
import { apiUser } from '@/lib/api-user'

/** DELETE /api/m/mock-exams/:id —— 删除模考成绩 */
export async function DELETE(_req: Request, { params }: { params: Promise<{ id: string }> }) {
  const user = await apiUser()
  if (!user) return Response.json({ error: '未登录' }, { status: 401 })

  const { id } = await params
  const exam = await prisma.mockExam.findUnique({ where: { id } })
  if (!exam || exam.userId !== user.id) return Response.json({ error: '记录不存在' }, { status: 404 })

  await prisma.mockExam.delete({ where: { id } })
  return Response.json({ ok: true })
}
