import { prisma } from '@/lib/prisma'
import { apiUser } from '@/lib/api-user'

/** POST /api/m/focus —— 保存一次专注记录 {durationMin, subject?} */
export async function POST(req: Request) {
  const user = await apiUser()
  if (!user) return Response.json({ error: '未登录' }, { status: 401 })

  const body = await req.json().catch(() => null)
  const durationMin = Math.min(240, Math.max(1, Number(body?.durationMin) || 25))
  const subject = String(body?.subject ?? '').trim() || null

  const record = await prisma.focusSession.create({
    data: { userId: user.id, durationMin, subject },
  })
  return Response.json({ record }, { status: 201 })
}
