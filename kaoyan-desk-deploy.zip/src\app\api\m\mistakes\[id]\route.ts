import { prisma } from '@/lib/prisma'
import { apiUser } from '@/lib/api-user'

/** DELETE /api/m/mistakes/:id —— 删除错题 */
export async function DELETE(_req: Request, { params }: { params: Promise<{ id: string }> }) {
  const user = await apiUser()
  if (!user) return Response.json({ error: '未登录' }, { status: 401 })

  const { id } = await params
  const mistake = await prisma.mistake.findUnique({ where: { id } })
  if (!mistake || mistake.userId !== user.id) return Response.json({ error: '记录不存在' }, { status: 404 })

  await prisma.mistake.delete({ where: { id } })
  return Response.json({ ok: true })
}
