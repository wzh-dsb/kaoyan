import { getSession } from '@/lib/auth'

/** 当前登录用户信息:GET + Authorization: Bearer <token> */
export async function GET() {
  const session = await getSession()
  if (!session) return Response.json({ error: '未登录' }, { status: 401 })

  const { user } = session
  return Response.json({
    user: {
      id: user.id,
      email: user.email,
      nickname: user.nickname,
      targetSchool: user.targetSchool,
      targetMajor: user.targetMajor,
      examDate: user.examDate,
    },
  })
}
