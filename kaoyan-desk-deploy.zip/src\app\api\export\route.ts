import { getSession } from '@/lib/auth'
import { prisma } from '@/lib/prisma'

// 导出当前用户全部数据为 JSON 文件(备份/迁移用)
export async function GET() {
  const session = await getSession()
  if (!session) return Response.json({ error: '未登录' }, { status: 401 })

  const uid = session.user.id
  const [tasks, habits, habitLogs, focusSessions, mockExams, phases, mistakes] =
    await Promise.all([
      prisma.task.findMany({ where: { userId: uid }, orderBy: { planDate: 'asc' } }),
      prisma.habit.findMany({ where: { userId: uid } }),
      prisma.habitLog.findMany({ where: { userId: uid }, orderBy: { date: 'asc' } }),
      prisma.focusSession.findMany({ where: { userId: uid }, orderBy: { startedAt: 'asc' } }),
      prisma.mockExam.findMany({ where: { userId: uid }, orderBy: { examDate: 'asc' } }),
      prisma.phase.findMany({ where: { userId: uid }, orderBy: { sortOrder: 'asc' } }),
      prisma.mistake.findMany({ where: { userId: uid }, orderBy: { createdAt: 'asc' } }),
    ])

  const data = {
    app: '考研工作台',
    version: 1,
    exportedAt: new Date().toISOString(),
    user: {
      email: session.user.email,
      nickname: session.user.nickname,
      examDate: session.user.examDate?.toISOString() ?? null,
      targetSchool: session.user.targetSchool,
      targetMajor: session.user.targetMajor,
    },
    tasks,
    habits,
    habitLogs,
    focusSessions,
    mockExams,
    phases,
    mistakes,
  }

  return new Response(JSON.stringify(data, null, 2), {
    headers: {
      'Content-Type': 'application/json; charset=utf-8',
      'Content-Disposition': 'attachment; filename="kaoyan-desk-export.json"',
    },
  })
}
