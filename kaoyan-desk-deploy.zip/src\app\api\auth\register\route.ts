import { prisma } from '@/lib/prisma'
import { hashPassword, SESSION_DAYS } from '@/lib/auth'

const EMAIL_RE = /^[^\s@]+@[^\s@]+\.[^\s@]+$/

/** 小程序/第三方客户端注册:POST {email, password, nickname?} → {token, user} */
export async function POST(req: Request) {
  const body = await req.json().catch(() => null)
  const email = String(body?.email ?? '').trim().toLowerCase()
  const password = String(body?.password ?? '')
  const nickname = String(body?.nickname ?? '').trim()

  if (!EMAIL_RE.test(email)) return Response.json({ error: '邮箱格式不正确' }, { status: 400 })
  if (password.length < 6) return Response.json({ error: '密码至少 6 位' }, { status: 400 })

  const exists = await prisma.user.findUnique({ where: { email } })
  if (exists) return Response.json({ error: '该邮箱已注册,请直接登录' }, { status: 409 })

  const user = await prisma.user.create({
    data: {
      email,
      nickname: nickname || null,
      passwordHash: await hashPassword(password),
    },
  })

  const token = crypto.randomUUID()
  await prisma.session.create({
    data: {
      token,
      userId: user.id,
      expiresAt: new Date(Date.now() + SESSION_DAYS * 86_400_000),
    },
  })

  return Response.json(
    {
      token,
      user: {
        id: user.id,
        email: user.email,
        nickname: user.nickname,
        targetSchool: null,
        targetMajor: null,
        examDate: null,
      },
    },
    { status: 201 },
  )
}
